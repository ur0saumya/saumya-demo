console.log("welcome to spotify");

//  initiialize the variables
let songIndex = 0;
let audioElement = new Audio('1.mp3');
let masterPlay = document.getElementsById('masterPlay');
let myprogressbar = document.getElementById('myprogressbar');
let songs = [
    {songName: "dooriyan", filepath: "C:\Users\Lenovo\OneDrive\Desktop\New folder (2)\Let Me Love You_128-(DJMaza).mp3", coverpath:"Let Me Love You_128-(DJMaza).jpg"}
    {songName: "dooriyan", filepath: "song/1.mp3", coverpath:"covers/1.jpg"}
    {songName: "dooriyan", filepath: "song/1.mp3", coverpath:"covers/1.jpg"}
    {songName: "dooriyan", filepath: "song/1.mp3", coverpath:"covers/1.jpg"}
    {songName: "dooriyan", filepath: "song/1.mp3", coverpath:"covers/1.jpg"}
    {songName: "dooriyan", filepath: "song/1.mp3", coverpath:"covers/1.jpg"}
    {songName: "dooriyan", filepath: "song/1.mp3", coverpath:"covers/1.jpg"}
    {songName: "dooriyan", filepath: "song/1.mp3", coverpath:"covers/1.jpg"}
]


//audioElement.play();

//handle play / pause click
masterPlay.addEventListener('click', ()=>{
    if(audioElement.paused || audioElement.currentTime<=0){
        audioElement.play();
        masterPlay.classList.remove('far fa-play-circle');
        masterPlay.classList.add('far fa-pause-circle');
    }
    else{
        audioElement.pause();
        masterPlay.classList.remove('far fa-pause-circle');
        masterPlay.classList.add('far fa-play-circle');
    }

})
//listen to events 
myprogressbar.addEventListener('timeupdate',()=>{
    consol.log('timeupdate');
    // update seekbar
})
